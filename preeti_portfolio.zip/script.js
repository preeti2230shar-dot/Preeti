const text = "Biotechnology Student | Research Enthusiast | Innovator";
let i = 0;

function typing() {
  if (i < text.length) {
    document.getElementById("typing").innerHTML += text.charAt(i);
    i++;
    setTimeout(typing, 50);
  }
}
typing();

const bars = document.querySelectorAll('.progress-bar');

window.addEventListener('scroll', () => {
  bars.forEach(bar => {
    const rect = bar.getBoundingClientRect();
    if (rect.top < window.innerHeight) {
      bar.style.width = bar.getAttribute('data-width');
    }
  });
});
